/***********************************************************************
* Copyright (c) 2020 All Right Reserved
*
* Author:	Creative Micro Systems
* Contact:	support@cmsgp.com
* File: 	main.c
* Summary:  Redis and DLMS Module.
*
**********************************************************************/

/* Includes */
#include "gen_inc.h"
#include "gen_fun.h"
#include "log.h"
#include "dlms_fun.h"
#include "dlms_api.h"
#include "hiredis.h"


int32_t fill_def_config(meter_comm_params_t *meter_comm_params);
int32_t redis_init(char *host, uint16_t port);
int32_t send_np_det_to_redis(obis_name_plate_info_t name_plate_info);
int32_t send_det_to_redis(char *msg, uint32_t len, char *key_name);
int32_t check_ls_data_file_avl(meter_comm_params_t meter_comm_params);
int32_t delete_old_files(meter_comm_params_t meter_comm_params);

meter_comm_params_t meter_comm_params;
block_val_info_t g_block_val_info;;

#define BILLING_INFO_KEY "billing_key_info"
		bill_val_info_t g_bill_val_info;
		
#define INST_POLL_TIME_REFF 	5
#define LS_POLL_TIME_REFF 		15*60
#define DP_POLL_TIME_REFF 		12*60*60
#define BILL_POLL_TIME_REFF 	12*60*60
#define EVENT_POLL_TIME_REFF 	10
#define INST_INFO_KEY 		"inst_info"

/* ---------------------------------------------------------- */
int32_t main(int argc,char** argv)
{
	static char fun_name[]="main()";
	int8_t 		fun_ret=-1;
	
	//fill_def_config(&meter_comm_params);
	
	redis_init("192.168.101.108",6379);
	
	serport_params_t serport_params;

	// Filling some default value to structure to start communication
	strcpy(serport_params.ser_port,"/dev/ttyS4");
	serport_params.baudrate=10;
	serport_params.databits=8;
	serport_params.stopbits=1;
	serport_params.parity=0;
	serport_params.handshake=NO_HANDSHAKE;
	serport_params.infmode=RS232_MODE;

	meter_comm_params.inf_type=INF_SERIAL;
	meter_comm_params.meter_type=LNT;
	meter_comm_params.meter_addr_format=1;
	
	if(meter_comm_params.meter_addr_format==1)
	{
		meter_comm_params.meter_id=3;
	}
	else
	{
		meter_comm_params.meter_id=19;
	}
	meter_comm_params.interface_params=&serport_params;
	sprintf(meter_comm_params.filename,"%s/meter_id_%02d",ROOT_DATA_DIR,meter_comm_params.meter_id);
	strcpy(meter_comm_params.meter_pass,"lnt1");
	
	fun_ret = init_comm(&meter_comm_params);
	if(fun_ret<0)
	{
		printf("Failed to initilized communication Error Code : %d\n",fun_ret);
		return -1;
	}
	
	printf("Initilized communication success\n");
	
	fun_ret = connect_to_meter(&meter_comm_params);
	if(fun_ret<0)
	{
		printf("Failed to connect to meter Error Code : %d\n",fun_ret);
		return -1;
	}
	
	gen_params_det_t 				gen_inst_param_det,gen_ls_param_det,gen_event_param_det,gen_bill_param_det,gen_daily_prof_param_det;
	
	fun_ret = get_obis_codes(&meter_comm_params,&gen_inst_param_det,&gen_ls_param_det,
	&gen_event_param_det,&gen_bill_param_det,&gen_daily_prof_param_det);
	if(fun_ret<0)
	{
		printf("Failed to get obis codes.Error Code : %d\n",fun_ret);
		return -1;
	}
	
	obis_name_plate_info_t name_plate_info;
	
	fun_ret = get_nameplate_details(&meter_comm_params, &name_plate_info);
	if(fun_ret<0)
	{
		printf("Failed to get nameplate details. Error Code : %d\n",fun_ret);
		return -1;
	}
	
	send_np_det_to_redis(name_plate_info);
	
	inst_val_info_t				g_inst_data_val;
	memset(&g_inst_data_val,0,sizeof(g_inst_data_val));
	
	fun_ret = get_inst_values(&meter_comm_params, &g_inst_data_val);
	if(fun_ret<0)
	{
		printf("Failed to get inst value. Error Code : %d\n",fun_ret);
		return -1;
	}
	else
	{
		
		send_det_to_redis((char*)&g_inst_data_val,sizeof(g_inst_data_val),INST_INFO_KEY);
	}
	
	fun_ret = get_ls_values_day_range(&meter_comm_params, LAST_NUM_DAYS_LS_READ);
	if(fun_ret<0)
	{
		printf("Failed to get prev load survey data. Error Code : %d\n",fun_ret);
		return -1;
	}
	else
	{
		check_ls_data_file_avl(meter_comm_params);
		
		#define LS_BLK_INFO_KEY 		"ls_blk_info"
		
		memcpy(&g_block_val_info,&meter_comm_params.meter_response,sizeof(block_val_info_t));
		
		send_det_to_redis((char*)&g_block_val_info,sizeof(block_val_info_t),LS_BLK_INFO_KEY);
	}
	
	fun_ret = get_midnight_data_all(&meter_comm_params);
	if(fun_ret<0)
	{
		printf("Failed to get midnight data. Error Code : %d\n",fun_ret);
		return -1;
	}
	else
	{
		// send_det_to_redis((char*)&g_block_val_info,sizeof(block_val_info_t),LS_BLK_INFO_KEY);
	}
	
	uint8_t event_class_type=0;
	event_val_info_t event_val_info;
	
	for(event_class_type=0; event_class_type<7; event_class_type++)
	{
		events_type_info_t events_type_info;
		fun_ret = get_event_data_all(&meter_comm_params,event_class_type);
		if(fun_ret<0)
		{
			printf("Failed to get midnight data. Error Code : %d\n",fun_ret);
			return -1;
		}
		else
		{
			#define EVENT_INFO_KEY "event_type_key_info"
			char event_key_buff[32];
			memset(event_key_buff,0,sizeof(event_key_buff));
			sprintf(event_key_buff,"%s_%d",EVENT_INFO_KEY,event_class_type);
			
			memcpy(&event_val_info,&meter_comm_params.meter_response,sizeof(event_val_info_t));
			send_det_to_redis((char*)&event_val_info,sizeof(event_val_info_t),event_key_buff);
		}
	}
	
	fun_ret = get_billing_info(&meter_comm_params);
	if(fun_ret<0)
	{
		printf("Failed to get midnight data. Error Code : %d\n",fun_ret);
		return -1;
	}
	else
	{
		memcpy(&g_bill_val_info,&meter_comm_params.meter_response,sizeof(g_bill_val_info));
		send_det_to_redis((char*)&g_bill_val_info,sizeof(bill_val_info_t),BILLING_INFO_KEY);
	}
	
	time_t curr_time,inst_time_to_read,ls_time_to_read,bill_time_to_read,event_time_to_read,dp_time_to_read;
	
	curr_time = time(NULL);
	inst_time_to_read = time(NULL);
	ls_time_to_read = time(NULL);
	bill_time_to_read = time(NULL);
	event_time_to_read = time(NULL);
	dp_time_to_read = time(NULL);
	
	while(1)
	{
		delete_old_files(meter_comm_params);
		
		curr_time = time(NULL);
		
		if((curr_time-inst_time_to_read)>INST_POLL_TIME_REFF)
		{
			inst_time_to_read=time(NULL);
			fun_ret = get_inst_values(&meter_comm_params, &g_inst_data_val);
			if(fun_ret<0)
			{
				printf("Failed to get inst value. Error Code : %d\n",fun_ret);
				//return -1;
			}
			else
			{
				send_det_to_redis((char*)&g_inst_data_val,sizeof(g_inst_data_val),INST_INFO_KEY);
			}
		}
		
		if((curr_time-ls_time_to_read)>LS_POLL_TIME_REFF)
		{
			ls_time_to_read=time(NULL);
			fun_ret = get_ls_values_block_range(&meter_comm_params,4);
			if(fun_ret<0)
			{
				printf("Failed to get inst value. Error Code : %d\n",fun_ret);
				//return -1;
			}
			else
			{
				memcpy(&g_block_val_info, &meter_comm_params.meter_response,sizeof(block_val_info_t));
				
				send_det_to_redis((char*)&g_block_val_info,sizeof(g_block_val_info),LS_BLK_INFO_KEY);
			}
		}
		
		if((curr_time-dp_time_to_read)>DP_POLL_TIME_REFF)
		{
			dp_time_to_read=time(NULL); 
			fun_ret = get_midnight_data(&meter_comm_params);
			if(fun_ret<0)
			{
				printf("Failed to get inst value. Error Code : %d\n",fun_ret);
				//return -1;
			}
			else
			{
				//memcpy(&g_block_val_info, &meter_comm_params.meter_response,sizeof(block_val_info_t));
				
				//send_det_to_redis((char*)&g_block_val_info,sizeof(g_block_val_info),LS_BLK_INFO_KEY);
			}
		}
		
		if((curr_time-event_time_to_read)>EVENT_POLL_TIME_REFF)
		{
			event_time_to_read=time(NULL); 
			for(event_class_type=0; event_class_type<7; event_class_type++)
			{
				events_type_info_t events_type_info;
				fun_ret = get_event_data(&meter_comm_params,event_class_type);
				if(fun_ret<0)
				{
					printf("Failed to get midnight data. Error Code : %d\n",fun_ret);
					return -1;
				}
				else
				{
					#define EVENT_INFO_KEY "event_type_key_info"
					char event_key_buff[32];
					memset(event_key_buff,0,sizeof(event_key_buff));
					sprintf(event_key_buff,"%s_%d",EVENT_INFO_KEY,event_class_type);
					
					memcpy(&event_val_info,&meter_comm_params.meter_response,sizeof(event_val_info_t));
					send_det_to_redis((char*)&event_val_info,sizeof(event_val_info_t),event_key_buff);
				}
			}
		}
		
		if((curr_time-bill_time_to_read)>BILL_POLL_TIME_REFF)
		{
			bill_time_to_read=time(NULL); 
			fun_ret = get_billing_info(&meter_comm_params);
			if(fun_ret<0)
			{
				printf("Failed to get inst value. Error Code : %d\n",fun_ret);
				//return -1;
			}
			else
			{
				memcpy(&g_bill_val_info,&meter_comm_params.meter_response,sizeof(g_bill_val_info));
				send_det_to_redis((char*)&g_bill_val_info,sizeof(bill_val_info_t),BILLING_INFO_KEY);
			}
		}
	}
	
	disconnect_meter(&meter_comm_params);
	
	return RET_SUCCESS;
}

void get_date(char *p_file_name,int *day,int *mon,int *year)
{
	char *token;
	char *delim = "_";
	char str[4][8];
	int idx = 0;
	
	memset(str,0,sizeof(str));
	token = strtok(p_file_name, delim);
	while( token != NULL )
	{
		memset(str[idx],0,8);
		strcpy(str[idx],token);
		token = strtok(NULL,delim);
		//printf("Token %d - %s\n",i,str[i]);
		idx++;
	}
	
	*day = atoi(str[0]);
	*mon = atoi(str[1]);
	*year = atoi(str[2]);

	//printf("day %d mon %d year %d\n",*day,*mon,*year);

	return;
}

int32_t delete_old_files(meter_comm_params_t meter_comm_params)
{
	static char 	fun_name[]="delete_old_files()";
	
	DIR 			*p_data_dir=NULL;
	struct dirent 	*p_dir_str=NULL;
	char 			file_name[64],dir_data_path[64];
	time_t 			curr_time,time_of_day;
	struct tm 		str_time,time_stamp;
	int32_t 		day,mon,year;
	
	
	time(&curr_time);
	localtime_r(&curr_time,&time_stamp);

	time_of_day = time(NULL);


/* sprintf(curr_ls_file_name,"%s/%02d_%02d_%04d",g_ls_data_dir_path,
									g_block_val_info.date_time.day,
									g_block_val_info.date_time.month,
									g_block_val_info.date_time.year); */
									
	memset(dir_data_path,0,sizeof(dir_data_path));
	sprintf(dir_data_path,"%s",meter_comm_params.filename);
	
	p_data_dir = opendir(dir_data_path);
	if ( p_data_dir == NULL )
	{
		printf("Failed to opendir %s\n",strerror(errno));
		return RET_NO_RESP;

	}
	while ( (p_dir_str = readdir(p_data_dir)) != NULL )
	{
		//printf("File name %s\n",p_dir_str->d_name);
		if (( strcmp(p_dir_str->d_name,".") == 0 ) || ( strcmp(p_dir_str->d_name,"..") == 0 ))
		{
			continue;
		}
		if (( strstr(p_dir_str->d_name,".txt") != NULL ) ||
			( strstr(p_dir_str->d_name,".tgz") != NULL)||
			( strcmp(p_dir_str->d_name,"od") == 0 )
			)
		{
			continue;
		}
		
		memset(file_name,0,sizeof(file_name));
		sprintf(file_name,"%s/%s",meter_comm_params.filename,p_dir_str->d_name);
		
		day = mon = year = 0;
		
		printf("getting date info for ls data file : %s\n",file_name);
		
		get_date(p_dir_str->d_name,&day,&mon,&year);

		str_time.tm_mday = day;
		str_time.tm_mon =  mon - 1;
		str_time.tm_year = year - 1900;
		str_time.tm_hour = 0;
		str_time.tm_min = 0;
		str_time.tm_sec = 0;

		time_of_day = mktime(&str_time);
		localtime_r(&time_of_day, &time_stamp);
		
		if ( ( curr_time - time_of_day ) >= OLD_DATA_FILES_TIME )
		{
			dbg_log(INFORM,"%-20s : Diff Time in day : %d, Time to delete the file : %s\n",
			fun_name,((curr_time - time_of_day)/(24*60*60)),file_name);
			
			remove(file_name);
		}
	}
	
	closedir(p_data_dir);
	
	return RET_SUCCESS;
}

void get_curr_date_time1(struct tm *curr_date_tm)
{
	time_t curr_time=0;
	time(&curr_time);
	
	struct tm *p_curr_time = localtime(&curr_time);
	printf("Current date file name : %02d_%02d_%04d\n",
	p_curr_time->tm_mday,p_curr_time->tm_mon+1,p_curr_time->tm_year+1900);
	
	memcpy(curr_date_tm,p_curr_time,sizeof(struct tm));
}

int32_t check_ls_data_file_avl(meter_comm_params_t meter_comm_params)
{
	struct stat file_st={0};
	uint8_t day_idx=0;
	char 	file_name[64]={0};
	char 	tot_ls_file_det[LAST_NUM_DAYS_LS_READ][64];
	
	struct tm st_time,time_stamp,curr_date_tm;
	time_t time_of_day=0,next_time_day=0,curr_time=0;
	uint8_t no_file_cnt=0;
	
	get_curr_date_time1(&curr_date_tm);

	st_time.tm_mday = curr_date_tm.tm_mday;
	st_time.tm_mon =  curr_date_tm.tm_mon ;
	st_time.tm_year = curr_date_tm.tm_year;
	st_time.tm_hour = curr_date_tm.tm_hour;
	st_time.tm_min = curr_date_tm.tm_min;
	st_time.tm_sec = curr_date_tm.tm_sec;
	printf("33 Current date file name : %02d_%02d_%04d\n",st_time.tm_mday,st_time.tm_mon+1,st_time.tm_year+1900);
	
	time_of_day = mktime(&st_time);
	//time_of_day -= (last_num_days_read*60*60);
	time_of_day -= (24*60*60);
	localtime_r(&time_of_day,&time_stamp);
	
	printf("22 Current date file name : %02d_%02d_%04d\n",time_stamp.tm_mday,time_stamp.tm_mon+1,time_stamp.tm_year+1900);
	
	for(day_idx=0; day_idx<LAST_NUM_DAYS_LS_READ; day_idx++)
	{
		printf("Current date file name : %02d_%02d_%04d\n",time_stamp.tm_mday,time_stamp.tm_mon+1,time_stamp.tm_year+1900);
		memset(file_name,0,sizeof(file_name));
		sprintf(file_name,"%s/%02d_%02d_%04d",meter_comm_params.filename,
		time_stamp.tm_mday,time_stamp.tm_mon+1,time_stamp.tm_year+1900);
		
		localtime_r(&time_of_day,&time_stamp);
		
		if(stat(file_name,&file_st)==-1)
		{
			printf("This LS data file is not available : %s\n",file_name);
			memset(tot_ls_file_det[day_idx],0,sizeof(tot_ls_file_det[day_idx]));
			strcpy(tot_ls_file_det[day_idx],file_name);
			time_of_day = time_of_day-(60*60*24);
			no_file_cnt++;
			continue;
		}
		time_of_day = time_of_day-(60*60*24);
	}
	
	if(no_file_cnt)
	{
		printf("Total Num of absent ls file : %d\n",no_file_cnt);
		for(day_idx=0; day_idx<no_file_cnt; day_idx++)
			printf("Absent File Name : %s\n",tot_ls_file_det[day_idx]);
	}
	
	return RET_SUCCESS;
}

#if 0

int32_t main1(int argc , char** argv)
{
	static char fun_name[]="main()";
	float p_flt_ptr=0.0;
	uint8_t obis[6]={0};
	
	printf("In Dlms Redis Programm\n");
	
	char p_msg[128];
	const char *hostname = "192.168.101.108";
    int port = 6379;
    struct timeval timeout = { 1, 500000 }; // 1.5 seconds
    
	redisContext *c;
	redisReply *reply;

	printf("Try to connect to Redis Server : %s\n",hostname);
	c = redisConnectWithTimeout(hostname, port, timeout);
    if (c == NULL || c->err) 
	{
        if (c) 
		{
            printf("Connection error: %s\n", c->errstr);
			printf("Disconnecting to Redis Server : %s\n",hostname);
            redisFree(c);
        } 
		else 
		{
            printf("Connection error: can't allocate redis context\n");
        }
		
        exit(1);
    }
	
	printf("Connected to Redis Server\n");
	
	/* PING server */
    reply = redisCommand(c,"PING");
    printf("PING: %s\n", reply->str);
	
    freeReplyObject(reply);

	meter_comm_params_t meter_comm_params;

	if(connect_to_meter(&meter_comm_params)<0)
	{
		printf("Failed to connect to meter\n");
		return -1;
	}
	
	obis_name_plate_info_t name_plate_info;
	if(get_nameplate_details(&meter_comm_params, &name_plate_info)<0)
	{
		printf("Failed to get nameplate details.\n");
		return -1;
	}
	else
	{
		printf("OBIS_CODE\t\tPARAMS_NAME\t\tPARAM_VALUE\n");
		
		printf("%d.%d.%d.%d.%d.%d\t\t%s\t\t%s\n",
				name_plate_info.meter_ser_num.param_obis_code[0],
				name_plate_info.meter_ser_num.param_obis_code[1],
				name_plate_info.meter_ser_num.param_obis_code[2],
				name_plate_info.meter_ser_num.param_obis_code[3],
				name_plate_info.meter_ser_num.param_obis_code[4],
				name_plate_info.meter_ser_num.param_obis_code[5],
				name_plate_info.meter_ser_num.param_name,
				name_plate_info.meter_ser_num.param_value
				);
		
		printf("%d.%d.%d.%d.%d.%d\t\t%s\t\t%s\n",
				name_plate_info.manf_name.param_obis_code[0],
				name_plate_info.manf_name.param_obis_code[1],
				name_plate_info.manf_name.param_obis_code[2],
				name_plate_info.manf_name.param_obis_code[3],
				name_plate_info.manf_name.param_obis_code[4],
				name_plate_info.manf_name.param_obis_code[5],
				name_plate_info.manf_name.param_name,
				name_plate_info.manf_name.param_value
				);
				
		printf("%d.%d.%d.%d.%d.%d\t\t%s\t\t%s\n",
				name_plate_info.fw_vwesion.param_obis_code[0],
				name_plate_info.fw_vwesion.param_obis_code[1],
				name_plate_info.fw_vwesion.param_obis_code[2],
				name_plate_info.fw_vwesion.param_obis_code[3],
				name_plate_info.fw_vwesion.param_obis_code[4],
				name_plate_info.fw_vwesion.param_obis_code[5],
				name_plate_info.fw_vwesion.param_name,
				name_plate_info.fw_vwesion.param_value
				);
				
		printf("%d.%d.%d.%d.%d.%d\t\t%s\t\t%d\n",
				name_plate_info.meter_type.param_obis_code[0],
				name_plate_info.meter_type.param_obis_code[1],
				name_plate_info.meter_type.param_obis_code[2],
				name_plate_info.meter_type.param_obis_code[3],
				name_plate_info.meter_type.param_obis_code[4],
				name_plate_info.meter_type.param_obis_code[5],
				name_plate_info.meter_type.param_name,
				name_plate_info.meter_type.param_value[0]
				);
		
		memcpy(&p_flt_ptr,&name_plate_info.int_ct_ratio.param_value,4);
		printf("%d.%d.%d.%d.%d.%d\t\t%s\t\t%0.5f\n",
				name_plate_info.int_ct_ratio.param_obis_code[0],
				name_plate_info.int_ct_ratio.param_obis_code[1],
				name_plate_info.int_ct_ratio.param_obis_code[2],
				name_plate_info.int_ct_ratio.param_obis_code[3],
				name_plate_info.int_ct_ratio.param_obis_code[4],
				name_plate_info.int_ct_ratio.param_obis_code[5],
				name_plate_info.int_ct_ratio.param_name,
				p_flt_ptr
				/* name_plate_info.int_ct_ratio.param_value */
				);
		
		p_flt_ptr=0.0;
		memcpy(&p_flt_ptr,&name_plate_info.int_pt_ratio.param_value,4);
		printf("%d.%d.%d.%d.%d.%d\t\t%s\t\t%0.5f\n",
				name_plate_info.int_pt_ratio.param_obis_code[0],
				name_plate_info.int_pt_ratio.param_obis_code[1],
				name_plate_info.int_pt_ratio.param_obis_code[2],
				name_plate_info.int_pt_ratio.param_obis_code[3],
				name_plate_info.int_pt_ratio.param_obis_code[4],
				name_plate_info.int_pt_ratio.param_obis_code[5],
				name_plate_info.int_pt_ratio.param_name,
				p_flt_ptr
				/* name_plate_info.int_pt_ratio.param_value */
				);
	
		printf("+++++++ Recv Nameplate info success\n");
	}
	
	//name_plate_info
	char key_name[32]="name_plate_det_key";
	
	reply = redisCommand(c, "HMSET %s stat %b", key_name, &name_plate_info, sizeof(name_plate_info));
	printf("Saveṣ status : %s\n", reply->str);//that shows +OK
		
	freeReplyObject(reply);

	printf("Disconnecting from Metere & closing connection\n",hostname);
	disconnect_meter(&meter_comm_params);
	
	/* Disconnects and frees the context */
	printf("Disconnecting to Redis Server : %s\n",hostname);
    
	redisFree(c);
	
	return RET_SUCCESS;
}

#endif

/* End Of File */