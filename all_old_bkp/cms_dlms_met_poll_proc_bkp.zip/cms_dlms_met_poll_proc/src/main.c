/* Include */
#include "gen_inc.h"
#include "dlms_api_config.h"
#include "log.h"
#include "hiredis.h"

/* Global */
char 					debug_file_name[64];
dlms_dcu_config_t 		*dlms_dcu_config;

redisContext 			*p_redis_handler=NULL;
redisReply 				*p_redis_reply=NULL;

/*  Local Micro*/
#define MET_POLL_LOG_FILE_NAME "cms_met_poll_proc.log"

int32_t redis_init(char *hostname, uint16_t port)
{
	static char fun_name[]="redis_init()";
	
	struct timeval timeout = { 1, 500000 }; // 1.5 seconds
	
	dbg_log(INFORM,"%-20s : Trying to connect on Redis Server : %s with port : %d\n",fun_name,hostname,port);
	
    p_redis_handler = redisConnectWithTimeout(hostname, port, timeout);
    if (p_redis_handler == NULL || p_redis_handler->err) 
	{
        if (p_redis_handler) 
		{
			dbg_log(INFORM,"%-20s : Connection error: %s\n",fun_name,p_redis_handler->errstr);
            
            redisFree(p_redis_handler);
        } 
		else 
		{
			dbg_log(INFORM,"%-20s : Connection error: can't allocate redis context\n",fun_name);
        }
    }
	
	dbg_log(INFORM,"%-20s : Connected on Redis Server : %s with port : %d\n",fun_name,hostname,port);
   
    freeReplyObject(p_redis_reply);
	
	return RET_SUCCESS;
}

void get_all_config(void)
{
	dlms_dcu_config=NULL;
	p_redis_reply=NULL;
	
	p_redis_reply = redisCommand(p_redis_handler, "HMGET %s stat", "DLMS_DCU_CONFIG");
	
	printf("1 , NumOfVector Elements : %d\n",p_redis_reply->elements);
	
	//dlms_dcu_config = 
	//dlms_dcu_config = p_redis_reply->element[0]->str;
	printf("2\n");
	
	printf("Start Flag : %02X\n",dlms_dcu_config->start_flag);
	
	printf("DCU_GEN_INFO DcuDevId : %d\n",dlms_dcu_config->dlms_dcu_info.dcu_dev_id);
	
	//printf("status :: IntVal : %d LongVal : %ld, test4Val : %d\n", response->myInt, response->myLong, response->sub_struct.test4);
	
	/* 
	
	printf("status :: IntVal : %d LongVal : %ld, test4Val : %d\n", response->myInt, response->myLong, response->sub_struct.test4);
	
	p_redis_reply = redisCommand(c, "HMSET %s stat %b", "DLMS_DCU_CONFIG", &dlms_dcu_config, sizeof(dlms_dcu_config));
	printf("Save statuṣs %s\n", p_redis_reply->str);//that shows +OK */
	
	freeReplyObject(p_redis_reply);
}

int32_t read_cfg_from_redis(void)
{
	//memset(&dlms_dcu_config,0,sizeof(dlms_dcu_config));
	p_redis_reply=NULL;
	
	char 	*p_gen_ptr=NULL;
	
	//p_redis_reply = redisCommand(p_redis_handler,"hmget DCU_GEN_INFO DcuDevId %d",dlms_dcu_config.dlms_dcu_info.dcu_dev_id);
	p_redis_reply = redisCommand(p_redis_handler,"hmget DCU_GEN_INFO DcuDevId");
	
	printf("Len : %d\n",p_redis_reply->len);
	
	if(p_redis_reply!=NULL)
	{
		printf("elements : %d\n",p_redis_reply->elements);

		//p_gen_ptr=p_redis_reply->element[0]->str;
		//p_gen_ptr=p_redis_reply->str;
		
		//printf("p_gen_ptr : %s\n",p_gen_ptr);
		
		/* if()
		{
			dlms_dcu_config.dlms_dcu_info.dcu_dev_id=atoi(p_redis_reply->element[0]->str);
			//g_ser_mon_flag=atoi(reply->element[0]->str);
		} */
		freeReplyObject(p_redis_reply);
	}
	else
		return -1;
	
	//printf("DCU_GEN_INFO DcuDevId : %d\n",dlms_dcu_config.dlms_dcu_info.dcu_dev_id);
	
	return 0;
}

int32_t read_bin_cfg(char *cfg_file_name)
{
	FILE *p_file_ptr=NULL;
	
	p_file_ptr=fopen(cfg_file_name,"r");
	
	if(p_file_ptr==NULL)
	{
		perror("fopen ");
		return -1;
	}
	
	fread(&dlms_dcu_config,sizeof(dlms_dcu_config),1,p_file_ptr);
	
	perror("fread ");
	
	fclose(p_file_ptr);
	
	return 0;
}

int32_t main(int argc,char** argv)
{
	redisContext *c;
    redisReply *reply;
    const char *hostname = (argc > 1) ? argv[1] : "127.0.0.1";
    //const char *hostname = (argc > 1) ? argv[1] : "192.168.101.108";
    int port = (argc > 2) ? atoi(argv[2]) : 6379;

    struct timeval timeout = { 1, 500000 }; // 1.5 seconds
    c = redisConnectWithTimeout(hostname, port, timeout);
    if (c == NULL || c->err) {
        if (c) {
            printf("Connection error: %s\n", c->errstr);
            redisFree(c);
        } else {
            printf("Connection error: can't allocate redis context\n");
        }
        exit(1);
    }

    /* PING server */
    /* reply = redisCommand(c,"PING");
    printf("PING: %s\n", reply->str);
    freeReplyObject(reply); */

	while(1)
	{
		// HMGET "DLMS_DCU_CONFIG" stat
		reply = redisCommand(c, "HMGET %s stat", "DLMS_DCU_CONFIG");
		printf("Array Len : %d\n",reply->elements);
		
		dlms_dcu_config_t *response = reply->element[0]->str;
		printf("status :: IntVal : %d\n", response->start_flag);
		freeReplyObject(reply);
		
		break;
	}
	
	redisFree(c);
	
	return 0;
}

int32_t main1(int argc,char** argv)
{
	static char fun_name[]="main()";
	
	memset(debug_file_name,0,sizeof(debug_file_name));
	sprintf(debug_file_name,"%s/%s",LOG_DIR,MET_POLL_LOG_FILE_NAME);
	
	redisContext 			*p_redis_handler=NULL;
	redisReply 				*p_redis_reply=NULL;

	if(redis_init("127.0.0.1",6379)!=RET_SUCCESS)
	{
		dbg_log(REPORT,"%-20s : Failed to initilised Redis Server\n",fun_name);
	}
	
	/* if(read_cfg_from_redis()!=RET_SUCCESS)
	{
		dbg_log(REPORT,"%-20s : Failed to read config from Redis Server\n",fun_name);
	} */
	
	get_all_config();
	
	/* if(read_bin_cfg("/usr/cms/config/dlms_api_config.cfg")!=RET_SUCCESS)
	{
		dbg_log(INFORM,"%-20s : Failed to read binary configuration\n",fun_name);
	} */
	
	
	return RET_SUCCESS;
}

/*  End Of File*/
