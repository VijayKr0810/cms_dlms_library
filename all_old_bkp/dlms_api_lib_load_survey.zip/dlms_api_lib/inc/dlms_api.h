#ifndef	__DLMS_API_H__
#define	__DLMS_API_H__


/* Error Code	Error 	Description*/
typedef enum
{
	RET_SUCCESS = 0,//	Function completed successfully
	RET_NO_RESP = -1,//	Meter didn’t respond
	RET_INCOMP_RESP = -2,//	Incomplete response received
	RET_CRC_FAIL = -3,//	CRC failed
	RET_AUTH_FAIL = -4,//	Authentication failed
	RET_PORT_OPEN_FAIL = -5,//	Failed to open serial port
	RET_ETH_CONN_FAIL = -6,//	Failed to connect to ethernet meter
	RET_DATA_NOT_AVAIL = -7,//	Data not available for the interval requested
	RET_VAL_OBIS_NP_FAIL = -8,//	Failed to get obis code for nameplate values
	RET_VAL_OBIS_INST_FAIL = -9,//	Failed to get obis code for instantaneous values
	RET_VAL_OBIS_LS_FAIL = -10,//	Failed to get obis code for load survey values
	RET_VAL_OBIS_MN_FAIL = -11,//	Failed to get obis code for midnight data values
	RET_VAL_OBIS_BILL_FAIL = -12,//	Failed to get obis code for billing info values
	RET_VAL_OBIS_EVENT_FAIL = -13,//	Failed get obis code for event data values
	RET_SCAL_OBIS_NP_FAIL = -14,//	Failed to get obis code for nameplate scalar values
	RET_SCAL_OBIS_INST_FAIL = -15,//	Failed to get obis code for instantaneous scalar values
	RET_SCAL_OBIS_LS_FAIL = -16,//	Failed to get obis code for load survey scalar values
	RET_SCAL_OBIS_MN_FAIL = -17,//	Failed to get obis code for midnight data scalar values
	RET_SCAL_OBIS_BILL_FAIL = -18, //	Failed to get obis code for billing info scalar values
	RET_SCAL_OBIS_EVENT_FAIL = -19,//	Failed get obis code for event data scalar values
	RET_SCAL_VAL_INST_FAIL = -20,//	Failed to get the scalar values for instantaneous parameters
	RET_SCAL_VAL_LS_FAIL = -21,//	Failed to get the scalar values for load survey parameters
	RET_SCAL_VAL_MN_FAIL = -22,	//Failed to get the scalar values for midnight data parameters
	RET_SCAL_VAL_BILL_FAIL = -23,//	Failed to get the scalar values for billing data parameters
	RET_SCAL_VAL_EVENT_FAIL = -24, //	Failed to get the scalar values for event data parameters
	RET_INVALID_INF_TYPE = -25, //Invalid interface type selected (SERIAL/TCP)
	RET_SNRM_FAILED_TYPE = -26, //Failed to initiate dlms communication.
	RET_DT_TIME_FAILED_TYPE = -27, //Failed to get date time from meter.
	RET_INST_VAL_FAILED_TYPE = -28 //Failed to get inst val from meter.
} error_type_t;

#define INF_SERIAL 					1
#define INF_TCP 					2
#define LNT 1
#define LNT_METER_MFG_TYPE		1
#define SECURE_METER_MFG_TYPE	2

typedef struct
{	
	char				ser_port[32];
	uint8_t             baudrate;     	// (index)Baudrate of serial port
	uint8_t             databits;      	// Num of databits
	uint8_t             stopbits;      	// Num of stop bits
	uint8_t             parity ;       	// Parity - ODD/EVEN/NONE
	uint8_t             handshake;     	// Handshake - SW/HW/NONE
	uint8_t             infmode;		// RS232 /485
	uint8_t             unused;
}serport_params_t;

typedef struct
{	
	char				meter_ipaddr[32];
	uint32_t			port;
}eth_params_t;


//Structures
typedef struct 
{
	uint8_t			day;
	uint8_t			month;
	uint16_t		year;
	uint8_t			hour;
	uint8_t			minute;
	uint8_t			second;
} date_time_t;


typedef struct
{
	int32_t 		fd;
	int8_t			inf_type;
	int8_t			meter_type;
	int32_t			meter_id;
	int8_t			meter_addr_format;
	date_time_t		from;
	date_time_t		to;
	int32_t			inf_params_len;
	void			*interface_params;
	int32_t			other_info1;
	int32_t			other_info2;
	char			filename[SIZE_128]; //file where the big data has to be stored
	char			meter_pass[SIZE_16]; //file where the big data has to be stored
	int32_t			resp_len;
	void			*meter_response;

}meter_comm_params_t;

typedef struct
{
	char    	meter_ser_num[32];
	char    	manf_name[32];
	char    	fw_vwesion[32];
	int32_t    	meter_type;
	int32_t    	int_ct_ratio;
	int32_t    	int_pt_ratio;
	int32_t    	met_store_type; //LIFO,FIFO
}name_plate_info_t;

typedef struct
{
	date_time_t			date_time;
	float				cur_ir;
	float				cur_iy;
	float				cur_ib;
	float				volt_r;
	float				volt_y;
	float				volt_b;
	float				pf_r;
	float				pf_y;
	float				pf_b;
	float				pf_avg;
	float				freq;
	float				kva;
	float				kw;
	float				kvar;
	float				num_pow_fail;
	float				cu_pf_dur;
	float				cu_ta_cnt;
	float				cu_bi_cnt;
	float				cu_pr_cnt;
	date_time_t			bill_date;
	float				kwh;
	float				kvarh_lag;
	float				kvarh_lead;
	float				kvah;
	float				kwmd;
	float				kvamd;
}inst_val_info_t;

typedef struct 
{
	date_time_t			date_time;
	float				freq;
	float				cur_ir;
	float 				cur_iy;
	float				cur_ib;
	float				volt_r;
	float				volt_y;
	float				volt_b;
	float				kwh_imp;
	float				kwh_exp;
	float				kvarh_lag;
	float				kvarh_lead;
	float				kvah_imp;
	float				kvah_exp;	
} block_val_info_t;


int8_t init_comm(meter_comm_params_t *meter_comm_params);
int8_t connect_to_meter(meter_comm_params_t *meter_comm_params);
int8_t get_nameplate_details(meter_comm_params_t *meter_comm_params, name_plate_info_t *name_plate_info);
int8_t get_inst_values(meter_comm_params_t *meter_comm_params, inst_val_info_t *recv_inst_data_val);
int8_t get_ls_values_block_range(meter_comm_params_t *meter_comm_params,uint8_t last_num_blk_read);
int8_t get_ls_values_hour_range(meter_comm_params_t *meter_comm_params,uint8_t last_num_hr_read);
int8_t get_ls_values_day_range(meter_comm_params_t *meter_comm_params,uint8_t last_num_days_read);

#endif

/* End Of File */