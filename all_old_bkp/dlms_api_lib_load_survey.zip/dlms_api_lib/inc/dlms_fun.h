
/****************************COSEM DATA TYPES*******************************/
#define		ARRAY_OF_ELE_TYPE		0x01
#define		STRUCTURE_OF_ELE_TYPE	0x02
#define		OCTET_STRING_TYPE		0x09
#define		VISIBLE_STRING_TYPE		0x0A
#define		SIGNED_8BIT_TYPE		0x0F
#define		UNSIGNED_8BIT_TYPE		0x11
#define		SIGNED_16BIT_TYPE		0x10
#define		UNSIGNED_16BIT_TYPE		0x12
#define		SIGNED_32BIT_TYPE		0x05
#define		UNSIGNED_32BIT_TYPE		0x06
#define		ENUM_TYPE 				0x16
#define		FLOAT_32BIT_TYPE		0x17
#define		LI_FO					0x01
#define		FI_FO					0x02


#define LNT_METER_MFG_TYPE		1
#define SECURE_METER_MFG_TYPE	2

/* Qry Type */
#define		SNRM_TYPE 					0x00
#define		AARQ_TYPE 					0x01
#define 	BLOCK_VALUES_TYPE			0X63
#define		DISC_TYPE					0x64
#define     NAME_PLATE_PARAMS_TYPE      0x04
#define		DATE_TIME_TYPE 				0x06
#define		CHECK_LIFO_OR_FIFO			0x21
#define		EVENT_ENTRIES_TYPE			0x22
#define		RR_TYPE						0x23
#define		INST_SCALE_OBIS_TYPE		0x10
#define		INST_SCALE_VAL_TYPE 		0x11
#define		INST_VAL_OBIS_TYPE			0x12
#define		INST_VALUES_TYPE 			0x13
#define		BLOCK_SCALER_OBIS_TYPE		0x14
#define		BLOCK_VAL_OBIS_TYPE 		0x15
#define		BLOCK_SCALER_VALUE_TYPE		0x16
#define		BLOCK_INT_PERIOD_TYPE		0x17

#define     DLMS_START_END_FLAG         0x7E
#define     FRAME_FORMAT_TYPE       	0xA000
#define     POLL_FINAL_BIT          	0x10


#define     PPPINITFCS16    			0xFFFF  // Initial FCS value
#define     PPPGOODFCS16     			0xF0B8  // Good final FCS value
#define     CTRL_SNRM_FRAME         	0x83
#define     CTRL_DISC_FRAME         	0x43
#define     I_FRAME                 	0x00 // last bit should be zero
#define     CTRL_RR_FRAME           	0x01
#define     CTRL_RNR_FRAME          	0x05
#define     AARQ_FRAME              	0x60
#define     AARE_FRAME              	0x61
#define     GET_REQUEST_NORMAL 			0xC001
#define     GET_REQUEST_NEXT_DATA_BLOCK	0xC002

typedef struct 
{
	uint8_t			data_type;
	uint8_t			num_bytes;
	uint8_t			value[32];
} gen_data_val_info_t;

typedef struct 
{
	uint8_t				obis_code[6];
	int8_t				value;
} scalar_det_t;

typedef struct
{
	uint8_t 		obis_code[6];
	char	      	param_name[16];
}param_det_t;

typedef struct 
{
	uint8_t   			tot_num_scalar;
	uint8_t   			tot_num_val_obis;
	uint8_t   			tot_num_value;
	scalar_det_t		scalar_val[80];
	uint8_t				val_obis[80][6];
} gen_params_det_t;


int32_t send_disc(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size );
int32_t send_snrm(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size);
int32_t send_aarq(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size, char*meter_pass);
int32_t send_msg_meter(uint8_t g_serial_fd, uint8_t* msg, int32_t len);
uint16_t pppfcs16 (uint16_t fcs, uint8_t *cp, int32_t len);
int32_t validate_met_resp(uint8_t* msg, int32_t len );
void print_data(uint8_t* msg, int32_t len);
int32_t proc_read_resp(uint8_t* msg, int32_t len);


int32_t get_curr_date_time(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size);

int32_t get_event_entry_order(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size);
int32_t send_get_next_blk(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size, uint32_t blk_val);
int32_t send_get_request(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size, uint16_t int_class, uint8_t*obis_code, uint8_t obis_len, uint16_t attr_no);

int8_t get_nameplate_info(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size, name_plate_info_t *name_plate_info);
int32_t send_rr_frame(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size);

int8_t get_obis_codes( meter_comm_params_t *meter_comm_params,
						gen_params_det_t *recv_gen_inst_param_det,
						gen_params_det_t *recv_gen_ls_param_det,
						gen_params_det_t *recv_gen_event_param_det,
						gen_params_det_t *recv_gen_bill_param_det,
						gen_params_det_t *recv_gen_daily_prof_param_det);
int32_t get_inst_obis_code_det(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size,gen_params_det_t *recv_gen_inst_param_det);

int32_t get_gen_val_obis(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size, uint8_t recv_qry_type, uint16_t int_class, uint8_t*obis_code, uint8_t obis_len, uint16_t attr_no);

int32_t get_gen_scalar_obis(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size,uint8_t recv_qry_type, uint16_t int_class, uint8_t*obis_code, uint8_t obis_len, uint16_t attr_no);

int32_t get_gen_val_obis(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size, uint8_t recv_qry_type, uint16_t int_class, uint8_t*obis_code, uint8_t obis_len, uint16_t attr_no);


int32_t fill_inst_val(void);

int32_t get_scaler_mf(int8_t mf,float *mf_val);
char* get_float_str(float recv_flt_val);

int32_t get_inst_val(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size, inst_val_info_t *recv_inst_data_val);


int8_t get_ls_obis_code_det(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size,gen_params_det_t*recv_gen_ls_param_det);
int32_t read_ls_data(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size);
int32_t read_today_ls_data(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size );
int32_t get_int_blk_period(uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size);
int32_t send_blk_profile_request( uint8_t comm_fd, uint32_t dlms_met_addr, uint8_t met_addr_size,uint16_t int_class, uint8_t*obis_code, uint8_t obis_len, uint16_t attr_no);
int32_t store_ls_date_time( uint8_t ls_idx, uint8_t index);
int32_t store_ls_val( uint8_t ls_idx, uint8_t index, float recv_flt_val);
int32_t fill_ls_val( uint8_t recv_ls_idx);
int32_t save_ls_data_file(void);

int32_t recv_ls_hour_range_data(meter_comm_params_t *meter_comm_params,uint8_t last_num_hr_read);
int32_t recv_ls_day_range_data(meter_comm_params_t *meter_comm_params,uint8_t last_num_days_read);
int32_t recv_ls_blk_range_data(meter_comm_params_t *meter_comm_params,uint8_t last_num_blk_read);
/* end of file */