#include "gen_inc.h"
#include "gen_fun.h"
#include "log.h"
#include "dlms_fun.h"
#include "dlms_api.h"

int main(void)
{
	static char fun_name[]="main()";
	meter_comm_params_t meter_comm_params;
	
	serport_params_t serport_params;

	// Filling some default value to structure to start communication
	strcpy(serport_params.ser_port,"/dev/ttyS4");
	serport_params.baudrate=10;
	serport_params.databits=8;
	serport_params.stopbits=1;
	serport_params.parity=0;
	serport_params.handshake=NO_HANDSHAKE;
	serport_params.infmode=RS232_MODE;

	meter_comm_params.inf_type=INF_SERIAL;
	meter_comm_params.meter_type=LNT;
	meter_comm_params.meter_id=18;
	meter_comm_params.meter_addr_format=4;
	meter_comm_params.interface_params=&serport_params;
	strcpy(meter_comm_params.filename,"./DlmsData");
	strcpy(meter_comm_params.meter_pass,"lnt1");
	
	if(init_comm(&meter_comm_params)<0)
	{
		printf("Failed to initilized communication.\n");
		return -1;
	}
	
	printf("Initilized communication success\n");
	
	if(connect_to_meter(&meter_comm_params)<0)
	{
		printf("Failed to connect to meter\n");
		return -1;
	}
	
	name_plate_info_t name_plate_info;
	
	if(get_nameplate_details(&meter_comm_params, &name_plate_info)<0)
	{
		printf("Failed to get nameplate details.\n");
		return -1;
	}
	else
	{
		printf("Meter Serial Num : %s\n",name_plate_info.meter_ser_num);
		printf("Meter MNF Name : %s\n",name_plate_info.manf_name);
		printf("Meter FW Name : %s\n",name_plate_info.fw_vwesion);
		printf("Meter Type : %d\n",name_plate_info.meter_type);
	}
	
	printf("+++++++ Recv Nameplate info success\n");

	gen_params_det_t 				gen_inst_param_det;
	gen_params_det_t 				gen_ls_param_det;
	gen_params_det_t 				gen_event_param_det;
	gen_params_det_t 				gen_bill_param_det;
	gen_params_det_t 				gen_daily_prof_param_det;
	
	if(get_obis_codes(&meter_comm_params,&gen_inst_param_det,&gen_ls_param_det,
	&gen_event_param_det,&gen_bill_param_det,&gen_daily_prof_param_det)<0)
	{
		printf("Failed to get obis codes..n");
		return -1;
	}
	
	inst_val_info_t				inst_data_val;
	
	if(get_inst_values(&meter_comm_params,&inst_data_val)<0)
	{
		printf("Failed to get inst value..n");
		return -1;
	}
	else
	{
		printf(">>>>>>>>>>>>>>>>>>>>>> Recv Nameplate info success\n");
		
		dbg_log(INFORM,"%-20s : INST TIME STAMP : %02d/%02d/%04d %02d:%02d:%02d\n",fun_name,
											inst_data_val.date_time.day,
											inst_data_val.date_time.month,
											inst_data_val.date_time.year,
											inst_data_val.date_time.hour,
											inst_data_val.date_time.minute,
											inst_data_val.date_time.second);

	dbg_log(INFORM,"%-20s : CURIR : %s\n",fun_name,get_float_str(inst_data_val.cur_ir));
	dbg_log(INFORM,"%-20s : CURIB : %s\n",fun_name,get_float_str(inst_data_val.cur_ib));
	dbg_log(INFORM,"%-20s : CURIY : %s\n",fun_name,get_float_str(inst_data_val.cur_iy));
	dbg_log(INFORM,"%-20s : VOLT1 : %s\n",fun_name,get_float_str(inst_data_val.volt_r));
	dbg_log(INFORM,"%-20s : VOLT2 : %s\n",fun_name,get_float_str(inst_data_val.volt_b));	
	dbg_log(INFORM,"%-20s : VOLT3 : %s\n",fun_name,get_float_str(inst_data_val.volt_y)); 	
	dbg_log(INFORM,"%-20s : FREQ : %s\n",fun_name,get_float_str(inst_data_val.freq)); 	
	dbg_log(INFORM,"%-20s : PF - R phase : %s\n",fun_name,get_float_str(inst_data_val.pf_r)); 
	dbg_log(INFORM,"%-20s : PF - B phase : %s\n",fun_name,get_float_str(inst_data_val.pf_b)); 	
	dbg_log(INFORM,"%-20s : PF - Y phase : %s\n",fun_name,get_float_str(inst_data_val.pf_y)); 	
	dbg_log(INFORM,"%-20s : PF 3 phases : %s\n",fun_name,get_float_str(inst_data_val.pf_avg)); 
	dbg_log(INFORM,"%-20s : App Power KVA : %s\n",fun_name,get_float_str(inst_data_val.kva)); 
	dbg_log(INFORM,"%-20s : Signed Active Power kW : %s\n",fun_name,get_float_str(inst_data_val.kw)); 
	dbg_log(INFORM,"%-20s : Reactive Power kvar : %s\n",fun_name,get_float_str(inst_data_val.kvar));	
	dbg_log(INFORM,"%-20s : Num Power Failure : %s\n",fun_name,get_float_str(inst_data_val.num_pow_fail)); 
	dbg_log(INFORM,"%-20s : Cumm Power Failure Duration : %s\n",fun_name,get_float_str(inst_data_val.cu_pf_dur));
	dbg_log(INFORM,"%-20s : Cumm Tamper Count : %s\n",fun_name,get_float_str(inst_data_val.cu_ta_cnt)); 
	dbg_log(INFORM,"%-20s : Cumm Billing Count : %s\n",fun_name,get_float_str(inst_data_val.cu_bi_cnt)); 
	dbg_log(INFORM,"%-20s : Cumm Programming Count : %s\n",fun_name,get_float_str(inst_data_val.cu_pr_cnt)); 
	dbg_log(INFORM,"%-20s : Cumm energy kWh : %s\n",fun_name,get_float_str(inst_data_val.kwh)); 
	dbg_log(INFORM,"%-20s : Cumm energy kvarh Lag : %s\n",fun_name,get_float_str(inst_data_val.kvarh_lag)); 
	dbg_log(INFORM,"%-20s : Cumm energy kvarh : %s\n",fun_name,get_float_str(inst_data_val.kvarh_lead)); 
	dbg_log(INFORM,"%-20s : Cumm energy kVAh : %s\n",fun_name,get_float_str(inst_data_val.kvah)); 
	/* dbg_log(INFORM,"%-20s : Bill Date stamp : %02d/%02d/%04d %02d:%02d:%02d\n",fun_name,
											bill_date_time.day,
											bill_date_time.month,
											bill_date_time.year,
											bill_date_time.hour,
											bill_date_time.minute,
											bill_date_time.second); */
	}
	
	//get_curr_date_ls_data();
	

	get_ls_values_block_range(&meter_comm_params,1);
	
	get_ls_values_hour_range(&meter_comm_params,10);
	
	printf("TestLib ::: RespLen : %d\n",meter_comm_params.resp_len);
	
	get_ls_values_day_range(&meter_comm_params,10);
	
	return 0;
}