#include "gen_inc.h"
#include "gen_fun.h"
#include "log.h"
#include "dlms_fun.h"
#include "dlms_api.h"


/**************************************************************************************************
*Function 					: init_comm()
*Input Parameters 			: Structure containing type of communication and the required parameters. 
							  Type identifying serial or ethernet.
*Output Parameters 			: Serial fd or socket fd.
*Return	Value				: Success or appropriate error code.
*Description 				: This API initializes the communication channel of DLMS devices. If the type is serial, 
							  initializes the serial port with the supplied parameters , 
							  if ethernet, initializes the tcp connection with the meter.
********************************************************************************************************/

int8_t init_comm(meter_comm_params_t *meter_comm_params)
{
	static char 	fun_name[]="init_comm()";
	uint8_t midx=0;
	
	/* strcpy(p_meter_passwd[0],meter_comm_params->meter_pass);
	g_dev_dest_addr[0]=meter_comm_params->meter_id;
	g_met_addr_size = meter_comm_params->meter_addr_format;
	
	dbg_log(INFORM,"%-20s : MetPass : %s, DestAddr : %d, AddrSize : %d\n",
	fun_name,p_meter_passwd[0],g_dev_dest_addr[0],g_met_addr_size); 
	
	strcpy(g_ls_data_dir_path,"./DlmsData");
	
	create_data_directory();
	
	switch(g_met_addr_size)
	{
		case 1:
			OFFSET=0;
			g_dev_dest_addr[0] = 3;
		break;
		
		case 2:
			OFFSET=1;
		break;
		
		case 4:
			OFFSET=3;
		break;
		
		default:
			OFFSET=0;
			g_dev_dest_addr[0] = 3;
		break;
	} */
	
	if(meter_comm_params->inf_type==INF_SERIAL)
	{
		return init_serial(meter_comm_params);
	}
	else if(meter_comm_params->inf_type==INF_TCP)
	{
		return init_tcp_conn(meter_comm_params);
	}
	else
	{
		return RET_INVALID_INF_TYPE;
	}
	return RET_SUCCESS;
}

/**************************************************************************************************
*Function 					: connect_to_meter()
*Input Parameters 			: Structure containing Commn  fd, meter id , password , type of meter.
*Output Parameters 			: Response packet.
*Return	Value				: Success or appropriate error code.
*Description 				: Sends DISC, SNRM and AARQ packets to the meter and get the response.
********************************************************************************************************/
int8_t connect_to_meter(meter_comm_params_t *meter_comm_params)
{
	static char fun_name[]="connect_to_meter()";
	uint8_t comm_fd, meter_id, meter_type;
	char password[16];
	int8_t ret_val=0,midx=0;
	
	ret_val = send_disc(meter_comm_params->fd,meter_comm_params->meter_id,meter_comm_params->meter_addr_format);
	if(ret_val<0)
	{
		dbg_log(REPORT,"%-20s : DISC Frame Qry  failed\n",fun_name);
		return ret_val;
	}
	
	ret_val = send_snrm(meter_comm_params->fd,meter_comm_params->meter_id,meter_comm_params->meter_addr_format);
	if(ret_val<0)
	{
		dbg_log(REPORT,"%-20s : SNRM Qry  failed\n",fun_name);
		return ret_val;
	}
	
	ret_val = send_aarq(meter_comm_params->fd,meter_comm_params->meter_id,meter_comm_params->meter_addr_format,meter_comm_params->meter_pass);
	if(ret_val<0)
	{
		dbg_log(REPORT,"%-20s : AARQ Qry  failed\n",fun_name);
		return ret_val;
	}
	
	dbg_log(REPORT,"%-20s : Meter connected succfully\n",fun_name);
	
	return RET_SUCCESS;
}

/**************************************************************************************************
*Function 					: get_nameplate_details()
*Input Parameters 			: Structure containing Commn  fd, meter id , password , type of meter.
*Output Parameters 			: Response structure with all the nameplate details.
*Return	Value				: Success or appropriate error code.
*Description 				: Get the nameplate information of the meter and return the decoded nameplate values in appropriate structure.
********************************************************************************************************/
//int8_t get_nameplate_details(meter_comm_params_t *meter_comm_params, name_plate_info_t *name_plate_info);
int8_t get_nameplate_details(meter_comm_params_t *meter_comm_params, name_plate_info_t *name_plate_info)
{
	get_nameplate_info(meter_comm_params->fd,
	meter_comm_params->meter_id,
	meter_comm_params->meter_addr_format,
	name_plate_info);
	
	printf("API Meter Serial Num : %s\n",name_plate_info->meter_ser_num);
	printf("API Meter MNF Name : %s\n",name_plate_info->manf_name);
	printf("API Meter FW Name : %s\n",name_plate_info->fw_vwesion);
	printf("API Meter Type : %d\n",name_plate_info->meter_type);
	
	return 0;
}

/**************************************************************************************************
*Function 					: get_obis_codes()
*Input Parameters 			: Structure containing Commn  fd, meter id , password , type of meter.
*Output Parameters 			: Response packet.
*Return	Value				: Success or appropriate error code.
*Description 				: This function does the following tasks
								•	gets values obis code of all the types of data . 
								•	get the scalar obis codes of all the types of data. 
								•	get the scalar value of all the types of data. 
********************************************************************************************************/
int8_t get_obis_codes( meter_comm_params_t *meter_comm_params,
						gen_params_det_t *recv_gen_inst_param_det,
						gen_params_det_t *recv_gen_ls_param_det,
						gen_params_det_t *recv_gen_event_param_det,
						gen_params_det_t *recv_gen_bill_param_det,
						gen_params_det_t *recv_gen_daily_prof_param_det)
{
	int8_t ret_val = 0;
	
	ret_val = get_inst_obis_code_det(meter_comm_params->fd,meter_comm_params->meter_id,meter_comm_params->meter_addr_format,recv_gen_inst_param_det);
	if(ret_val<0)
	{
		return ret_val;
	}
	else
	{
		printf("Recv Inst obis code info\n");
	}
	
	/* ret_val = get_ls_obis_code_det(meter_comm_params->fd,meter_comm_params->meter_id,meter_comm_params->meter_addr_format,recv_gen_ls_param_det);
	if(ret_val<0)
	{
		return ret_val;
	}
	else
	{
		printf("Recv Ls obis code info\n");
	} */
	
	return RET_SUCCESS;
}

/**************************************************************************************************
*Function 					: get_inst_values()
*Input Parameters 			: Structure containing Commn  fd, meter id , password , type of meter.
*Output Parameters 			: Response packet.
*Return	Value				: Success or appropriate error code.
*Description 				: Get the instantaneous data  of the meter and return the decoded values of instantaneous data in appropriate structure
********************************************************************************************************/
int8_t get_inst_values(meter_comm_params_t *meter_comm_params, inst_val_info_t *recv_inst_data_val)
{
	if(get_inst_val(meter_comm_params->fd,meter_comm_params->meter_id,meter_comm_params->meter_addr_format,recv_inst_data_val)<0)
	{
		return RET_INST_VAL_FAILED_TYPE;
	}
	else
	{
		printf("+++++++++++++++++++Recv Inst data\n");
	}
	
	return 0;
}

/* End of file */