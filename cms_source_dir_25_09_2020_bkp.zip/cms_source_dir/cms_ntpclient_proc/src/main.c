#include "gen_inc.h"
#include "log.h"
#include "dlms_api_config.h"
#include "/home/iot-gateway/hiredis/hiredis.h"